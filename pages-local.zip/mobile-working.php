
<!DOCTYPE html>
<html lang="en">
<head>
<!--***************************************-->
<script src="js/bootstrap.min.js" ></script>
<!--***************************************-->


	<title>StoreToGo Dubai UAE</title>
	<!-- <meta name="description" content="Floors born tough, our floor tiles are Strong, Durable & Aesthetic.  Our product applications can be used in diverse segment from Industries, Warehouses to Stables, from Gymnasiums, Hospitals, Swimming pool, Garage, Exhibitions to Events the list goes on. Our portfolio includes PVC tiles, Heavy Duty Tiles, Work-Station Mats, Ergonomic Anti-Fatigue mats, Entrance floor matting, Outdoor tiles and Sports tiles. Contact stroetogofloor.ae Sharjah, UAE for more information."> -->
	<link rel="shortcut icon" href="images/favicon.png">
	<meta charset="utf-8">
	<meta name="keywords" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="canonical" href="" />
	

<!--***************************************-->
<!-- FONT --> 

  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic" />
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Montserrat:400,700" />
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700">  
      
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700"> 
<!--***************************************-->

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<!-- CSS  ***************************************-->		  
	<link rel="stylesheet" href="css/bootstrap.min.css" >

  <link rel="stylesheet" href="css/prod-style.css" >
	<link rel="stylesheet" href="css/layout.css" >
	<link rel="stylesheet" href="css/home.css" >
  <link rel="stylesheet" href="css/testim.css" >
  <link rel="stylesheet" href="css/product.css" >
<!--***************************************-->




</head>
<body>


<?php $page ='product';  include'header.php';?>

<!-- EMAIL -->
<?php $page ='product';  include'express.php';?>
<!-- EMAIL -->

<section class="page-pro">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <h4><a href="index.php">Home</a> > Mobile Working</h4>
      </div>
    </div>
  </div>
  
</section>


 <section id="serico-hg" style="padding-bottom: 0px">
    <div class="container-fluid">

<!-- STRT -->
<div class="row sty-wid">
  <div class="yCmsComponent sortimo-component-slot clearfix">
<div id="comp_000019QS" class="sortimo-component text-component big-header
">
<h1 class="component-headline ">
        
       Mobile working made easy!
      </h1>
    
<div class="text">
      <p style="text-align: center;">Maximum flexibility in day-to-day work with mobile “helpers” from StoreToGo.</p></div>
  </div></div>
</div>

</div>
</section>


<section id="serico">
  <div class="container-fluid">
   
  <div class="yCmsComponent sortimo-component-slot clearfix ">
<div class="sortimo-component slots-component" id="comp_00002TVL">
  <div class="item-wrapper">
    <a href="">
      <div class="slot-item sortimo-blue-hover sortimo-white-link big-slot ">
        <div class="image-container kdkk">
          <img src="images/product/mobiles-arbeiten-slot-workmo-690x340.jpg" class="image-zoom ">
        </div>
        <div class="text-container lskk" style="background-color: rgb(0, 104, 180); color: rgb(255, 255, 255); height: 92.4px;">
          <div class="text">
            WorkMo – the mobile workplace</div>
        </div>
      </div>
      </a>
      <a href="">
      <div class="slot-item sortimo-blue-hover sortimo-white-link big-slot ">
        <div class="image-container kdkk">
          <img src="images/product/sContainer-kacheln-2-groessen-690x340.jpg" class="image-zoom ">
        </div>
        <div class="text-container lskk" style="background-color: rgb(0, 104, 180); color: rgb(255, 255, 255); height: 92.4px;">
          <div class="text">
            sContainer – the customisable service depot</div>
        </div>
      </div>
      </a>
      </div>
</div></div>

</div></section>



 <section id="serico-hg" >
    <div class="container-fluid">

<!-- STRT -->
<div class="row sty-wid1">

<div class="yCmsComponent sortimo-component-slot clearfix centet-all">
<div class="sortimo-component wide-high text-picture-component wide-high-left" id="comp_00002TVM">
  <div class="row" style="background-color: #eeeff1;">
    <div class="image-container" style="width: 695px; height: 510px;
        background-image: url('images/product/mobiles-arbeiten-sContainer-695x510.jpg');  float: left;">
        <img src="images/product/mobiles-arbeiten-sContainer-695x510.jpg" style="visibility: hidden;">
      </div>  
    <div class="sortimo-blue-link text-container sortimo-dark-hover khsism" style="width: 695px; min-height: 510px; float: right;background-color: #eeeff1;color: #546373;
      ">
      <div class="arrow-container" style="background-color: #eeeff1;"></div>
      
    
      <h2 class="component-headline ">
        
        sContainer – the customisable service depot
      </h2>
    
<div class="text">
        <p>As a service depot in pallet format, the sContainer serves as a flexible companion for service technicians, tradespeople and construction workers. Thanks to the option of fitting it with the SR5 racking system, the sContainer is not only a mobile depot, but also an organisational system at any construction site or any service job – with just a minimal footprint.</p>
        </div>
    </div>
    </div>
</div></div>

</div>
<!-- END -->

<!-- STRT -->
<div class="row sty-wid">

<div class="yCmsComponent sortimo-component-slot clearfix centet-all">
<div class="sortimo-component wide-high text-picture-component wide-high-right" id="comp_00002TVN">
  <div class="row" style="background-color: #eeeff1;">
    <div class="sortimo-blue-link text-container sortimo-dark-hover khsism" style="width: 695px; min-height: 510px; float: left;background-color: #eeeff1;color: #546373;
      ">
      <div class="arrow-container" style="background-color: #eeeff1;"></div>
       <h2 class="component-headline ">
        
        WorkMo – the mobile workplace
      </h2>
    
  
<div class="text">
        <p>As a modular system, the WorkMo can be assembled individually and used in any situation you can think of; as a mobile work bench, a workshop trolley, workshop shelves, transport equipment or a mobile workplace.</p><p>The modules, with their different widths and heights mean that the WorkMo can be assembled to suit individual requirements and can be adapted at any time.</p>
        </div>
    </div>
    <div class="image-container" style="width: 695px; height: 510px;
        background-image: url('images/product/mobiles-arbeiten-workmo-695x510.jpg');  float: right;">
        <img src="images/product/mobiles-arbeiten-workmo-695x510.jpg" style="visibility: hidden;">
      </div>  
    </div>
</div></div>

</div>
<!-- END -->


<!-- STRT -->
<div class="row sty-wid">

<div class="yCmsComponent sortimo-component-slot clearfix centet-all">
<div class="sortimo-component wide-high text-picture-component wide-high-left" id="comp_00002TVO">
  <div class="row" style="background-color: #eeeff1;">
    <div class="image-container" style="width: 695px; height: 510px;
        background-image: url('images/product/mobiles-arbeiten-boxxen-koffer-695x510.jpg');  float: left;">
        <img src="images/product/mobiles-arbeiten-boxxen-koffer-695x510.jpg" style="visibility: hidden;">
      </div>  
    <div class="sortimo-blue-link text-container sortimo-dark-hover khsism" style="width: 695px; min-height: 510px; float: right;background-color: #eeeff1;color: #546373;
      ">
      <div class="arrow-container" style="background-color: #eeeff1;"></div>
      
      <h2 class="component-headline ">
        
        Case and BOXXes – convenient organisational aids
      </h2>
    
<div class="text">
        <p>The practical organisational systems, such as cases and BOXXes, make mobile working efficient and clearly arranged and with their push-in and carry function they are versatile multitaskers. The WorkMo and sContainer are compatible with the StoreToGo cases and BOXXes so together they create more order and clearer arrangement at the workplace.</p>
        </div>
    </div>
    </div>
</div></div>

</div>
<!-- END -->




<!-- STRT -->
<div class="row sty-wid1">
  
</div>
<!-- END -->

    </div>
  </section>




    
    <?php include'footer.php';?>
    

   
    <script type="text/javascript" src="js/storetogoModules.js"></script>
    
    
    

<script type="text/javascript">
  // vars
'use strict'
var testim = document.getElementById("testim"),
    testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
    testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
    testimLeftArrow = document.getElementById("left-arrow"),
    testimRightArrow = document.getElementById("right-arrow"),
    testimSpeed = 4500,
    currentSlide = 0,
    currentActive = 0,
    testimTimer,
    touchStartPos,
    touchEndPos,
    touchPosDiff,
    ignoreTouch = 30;
;

window.onload = function() {

    // Testim Script
    function playSlide(slide) {
        for (var k = 0; k < testimDots.length; k++) {
            testimContent[k].classList.remove("active");
            testimContent[k].classList.remove("inactive");
            testimDots[k].classList.remove("active");
        }

        if (slide < 0) {
            slide = currentSlide = testimContent.length-1;
        }

        if (slide > testimContent.length - 1) {
            slide = currentSlide = 0;
        }

        if (currentActive != currentSlide) {
            testimContent[currentActive].classList.add("inactive");            
        }
        testimContent[slide].classList.add("active");
        testimDots[slide].classList.add("active");

        currentActive = currentSlide;
    
        clearTimeout(testimTimer);
        testimTimer = setTimeout(function() {
            playSlide(currentSlide += 1);
        }, testimSpeed)
    }

    testimLeftArrow.addEventListener("click", function() {
        playSlide(currentSlide -= 1);
    })

    testimRightArrow.addEventListener("click", function() {
        playSlide(currentSlide += 1);
    })    

    for (var l = 0; l < testimDots.length; l++) {
        testimDots[l].addEventListener("click", function() {
            playSlide(currentSlide = testimDots.indexOf(this));
        })
    }

    playSlide(currentSlide);

    // keyboard shortcuts
    document.addEventListener("keyup", function(e) {
        switch (e.keyCode) {
            case 37:
                testimLeftArrow.click();
                break;
                
            case 39:
                testimRightArrow.click();
                break;

            case 39:
                testimRightArrow.click();
                break;

            default:
                break;
        }
    })
    
    testim.addEventListener("touchstart", function(e) {
        touchStartPos = e.changedTouches[0].clientX;
    })
  
    testim.addEventListener("touchend", function(e) {
        touchEndPos = e.changedTouches[0].clientX;
      
        touchPosDiff = touchStartPos - touchEndPos;
      
        console.log(touchPosDiff);
        console.log(touchStartPos); 
        console.log(touchEndPos); 

      
        if (touchPosDiff > 0 + ignoreTouch) {
            testimLeftArrow.click();
        } else if (touchPosDiff < 0 - ignoreTouch) {
            testimRightArrow.click();
        } else {
          return;
        }
      
    })
}
</script>



    
   
</body>
</html>
