
<!DOCTYPE html>
<html lang="en">
<head>
<!--***************************************-->
<script src="js/bootstrap.min.js" ></script>
<!--***************************************-->


	<title>StoreToGo Dubai UAE</title>
	<!-- <meta name="description" content="Floors born tough, our floor tiles are Strong, Durable & Aesthetic.  Our product applications can be used in diverse segment from Industries, Warehouses to Stables, from Gymnasiums, Hospitals, Swimming pool, Garage, Exhibitions to Events the list goes on. Our portfolio includes PVC tiles, Heavy Duty Tiles, Work-Station Mats, Ergonomic Anti-Fatigue mats, Entrance floor matting, Outdoor tiles and Sports tiles. Contact stroetogofloor.ae Sharjah, UAE for more information."> -->
	<link rel="shortcut icon" href="images/favicon.png">
	<meta charset="utf-8">
	<meta name="keywords" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="canonical" href="" />
	

<!--***************************************-->
<!-- FONT --> 

  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic" />
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Montserrat:400,700" />
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700">  
      
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700"> 
<!--***************************************-->

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<!-- CSS  ***************************************-->		  
	<link rel="stylesheet" href="css/bootstrap.min.css" >

  <link rel="stylesheet" href="css/prod-style.css" >
	<link rel="stylesheet" href="css/layout.css" >
	<link rel="stylesheet" href="css/home.css" >
  <link rel="stylesheet" href="css/testim.css" >
  <link rel="stylesheet" href="css/product.css" >
<!--***************************************-->




</head>
<body>


<?php $page ='product';  include'header.php';?>

<!-- EMAIL -->
<?php $page ='product';  include'express.php';?>
<!-- EMAIL -->

<section class="page-pro">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <h4><a href="index.php">Home</a> > <a href="#">StoreToGo labels configurator</a> > labels for the SR5</h4>
      </div>
    </div>
  </div>
  
</section>




  <section id="serico-hg" style="margin-top: 60px">
    <div class="container-fluid">
      <div class="row styd">


<div class="yCmsComponent sortimo-component-slot clearfix">
<div id="comp_00002T37" class="sortimo-component text-component big-header
">
   
      <h3 class="component-headline ">
        
        Workplace organisation made easy.
      </h3>
    
    
    
      <div class="component-headline subheadline">
        
        Individual and convenient.
      </div>
    
    
  
<div class="text">
      <p class="ttt-par">Structure your SR5 van racking systems with StoreToGo labels. It’s child’s play labelling shelves, drawers, BOXXes and cases in the configurator on the SR5 van racking system. As part of the <a href="workplace-organisation.php">5S method</a>, StoreToGo labels help create an extremely efficient working environment, save you time and money and make a professional impression on your customers.</p></div>
  </div></div>

</div>

<div class="row styd">
  <div class="yCmsComponent sortimo-component-slot clearfix" style="margin-top:30px;">
<div id="comp_00002TVJ" class="sortimo-component text-component small-header
">
   <h2 class="component-headline ">
        
        You have two options to create labels for your SR5:
      </h2>
    
  
</div></div>

<div class="yCmsComponent sortimo-component-slot clearfix" >
<div class="sortimo-component slots-component" id="comp_00002TVH">
  <div class="item-wrapper">
    <a href="">
      <div class="slot-item sortimo-blue-hover sortimo-white-link big-slot njhmn">
        <div class="image-container">
          <img src="images/product/leer-690x340.gif" class="image-zoom ">
        </div>
        <div class="text-container" style="background-color: rgb(0, 104, 180); color: rgb(255, 255, 255); height: 92.4px;">
          <div class="text">
            1. Directly during configuration of your SR5</div>
        </div>
      </div>
      </a>
      <a href="">
      <div class="slot-item sortimo-blue-hover sortimo-white-link big-slot njhmn">
        <div class="image-container">
          <img src="images/product/leer-690x340.gif" class="image-zoom ">
        </div>
        <div class="text-container" style="background-color: rgb(0, 104, 180); color: rgb(255, 255, 255); height: 92.4px;">
          <div class="text">
            2. Later, when you are already using the SR5</div>
        </div>
      </div>
      </a>
      </div>
</div></div>

<div class="yCmsComponent sortimo-component-slot clearfix nex-t">
<div class="sortimo-component tile-component" id="">
  <div class="low single-tile wide bsdf" style="background-image: url('images/product/arbeitsplatzorga-labels-aftersales-kacheln-FZGausw-690x340-EN.jpg'); ">
      <div class="sortimo-tile-from-left sortimo-animate sortimo-tile-left" style="display: block;">
          <div class="text">
            <div class="align-container">
              

      <h2 class="component-headline ">
        
        Planing labels during the configuration?
      </h2>
    
    
    
  
<p class="tile-text">
                </p>
             </div>
          </div>
        </div>
      </div>
  <div class="low single-tile wide bsdf" style="background-image: url('images/product/arbeitsplatzorga-labels-aftersales-kacheln-configID-690x340-EN.gif'); ">
      <div class="sortimo-animate sortimo-tile-from-left" style="display: block;">
          <div class="text">
            <div class="align-container">
     
    
      <h1 class="component-headline ">
        
        SR5 already purchased? 
      </h1>
    
    
    
  
<p class="tile-text">
                </p>
           </div>
          </div>
        </div>
      </div>
  </div></div>


<div class="yCmsComponent sortimo-component-slot clearfix" style="margin-top: 40px">
<div id="comp_00002TVF" class="sortimo-component text-component big-header
">
  
      <h2 class="component-headline ">
        
        StoreToGo labels make your day-to-day work easier
      </h2>

</div></div>



<div class="yCmsComponent sortimo-component-slot clearfix boxxxx">
<div class="sortimo-component slots-component" id="cmsitem_00006117">
  <div class="item-wrapper">
    <div class="slot-item sortimo-blue-hover sortimo-white-link small-slot small-margin redf">
        <div class="image-container">
          <img src="images/product/arbeitsplatzorga-labels-aftersales-slots-ordnung-340x340.jpg" class="">
        </div>
        <div class="text-container" style="background-color: rgb(124, 140, 156); color: rgb(255, 255, 255); height: 210.6px;">
          <div class="text">
            <div style="margin: 15px 0 20px 0; font-size: 19px; width: 260px; max-width: 340px;">
<p style="text-align: center; font-weight: 700; margin-bottom:20px;">More order</p>

<p style="text-align:left; font-weight: 300;">Individual labelling prevents redundant inventory.<br>&nbsp;</p>

<p style="text-align:left; font-weight: 300;"></p>
</div>
</div>
        </div>
      </div>





      <div class="slot-item sortimo-blue-hover sortimo-white-link small-slot small-margin redf">
        <div class="image-container">
          <img src="images/product/arbeitsplatzorga-labels-aftersales-slots-zugriff-340x340.jpg" class="">
        </div>
        <div class="text-container" style="background-color: rgb(0, 104, 180); color: rgb(255, 255, 255); height: 210.6px;">
          <div class="text">
            <div style="margin: 15px 0 20px 0; font-size: 19px; width: 260px; max-width: 340px;">
<p style="text-align: center; font-weight: 700; margin-bottom:20px;">Quick access</p>

<p style="text-align:left; font-weight: 300;">Clearer arrangement of contents thanks to the StoreToGo colour coding.<br>&nbsp;</p>

<p style="text-align:left; font-weight: 300;"></p>
</div>
</div>
        </div>
      </div>

      <div class="slot-item sortimo-blue-hover sortimo-white-link small-slot small-margin redf" style="margin-top: 10px">
        <div class="image-container">
          <img src="images/product/arbeitsplatzorga-labels-aftersales-slots-zeitersparnis-340x340.jpg" class="">
        </div>
        <div class="text-container" style="background-color: rgb(124, 140, 156); color: rgb(255, 255, 255); height: 210.6px;">
          <div class="text">
            <div style="margin: 15px 0 20px 0; font-size: 19px; width: 260px; max-width: 340px;">
<p style="text-align: center; font-weight: 700; margin-bottom:20px;">More time saved</p>

<p style="text-align:left; font-weight: 300;">Consistent labelling speeds up the refilling process.<br>&nbsp;</p>

<p style="text-align:left; font-weight: 300;"></p>
</div>
</div>
        </div>
      </div>


      <div class="slot-item sortimo-blue-hover sortimo-white-link small-slot small-margin redf">
        <div class="image-container">
          <img src="images/product/fahrzeugeinrichtung-sr5-online-konfigurieren-340x340.jpg" class="">
        </div>
        <div class="text-container" style="background-color: rgb(0, 104, 180); color: rgb(255, 255, 255); height: 210.6px;">
          <div class="text">
            <div style="margin: 15px 0 20px 0; font-size: 19px; width: 260px; max-width: 340px;">
<p style="text-align: center; font-weight: 700; margin-bottom:20px;">Easy configuration</p>

<p style="text-align:left; font-weight: 300;">Can be ordered ready for use with the SR5 van racking system.<br>&nbsp;</p>

<p style="text-align:left; font-weight: 300;"></p>
</div>
</div>
        </div>
      </div>



      </div>
</div></div>



<div class="yCmsComponent sortimo-component-slot clearfix" style="margin-top: 40px">
<div id="comp_00002T4F" class="sortimo-component text-component big-header
">
   <h2 class="component-headline ">
        
        Advantages of the StoreToGo labels configurator
      </h2>
    
    
    
  
</div></div>

<div class="yCmsComponent sortimo-component-slot clearfix">
<div class="sortimo-component highlight-component" id="comp_00002T3V" style="background-color: #eeeff1;color: #546373; fill: #546373;">
  <div class="text-image-container">
    <div class="left-text">
      <div class="sortimo-dark-hover highlight-item sortimo-blue-link">
          <div class="component-headline">
                  <span class="icon-span"><svg id="" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35"><defs><style>.icon-produkthighlights-check-cls-1{fill:#546373;}.icon-produkthighlights-check-cls-2{fill:#fff;}</style></defs><title>icon-produkthighlights-check</title><circle class="icon-produkthighlights-check-cls-1" cx="17.5" cy="17.5" r="17.5"></circle><path class="icon-produkthighlights-check-cls-2" d="M-33.71-3.63a1.49,1.49,0,0,0-2.1,0h0l-8.83,9.52L-47.8,2.29a1.47,1.47,0,0,0-2.07-.17h0A1.54,1.54,0,0,0-50,4.27l4.23,4.91a1.48,1.48,0,0,0,1.09.52h0a1.52,1.52,0,0,0,1.08-.48l10-10.69A1.56,1.56,0,0,0-33.71-3.63Z" transform="translate(59.33 14.77)"></path></svg></span>
                  <span class="text-span">
                    Intuitive operation</span>
                </div>
              <div class="text">
            <p>Easy creation of labels in a just few clicks </p></div>
        </div>
      <div class="sortimo-dark-hover highlight-item sortimo-blue-link">
          <div class="component-headline">
                  <span class="icon-span"><svg id="" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35"><defs><style>.icon-produkthighlights-check-cls-1{fill:#546373;}.icon-produkthighlights-check-cls-2{fill:#fff;}</style></defs><title>icon-produkthighlights-check</title><circle class="icon-produkthighlights-check-cls-1" cx="17.5" cy="17.5" r="17.5"></circle><path class="icon-produkthighlights-check-cls-2" d="M-33.71-3.63a1.49,1.49,0,0,0-2.1,0h0l-8.83,9.52L-47.8,2.29a1.47,1.47,0,0,0-2.07-.17h0A1.54,1.54,0,0,0-50,4.27l4.23,4.91a1.48,1.48,0,0,0,1.09.52h0a1.52,1.52,0,0,0,1.08-.48l10-10.69A1.56,1.56,0,0,0-33.71-3.63Z" transform="translate(59.33 14.77)"></path></svg></span>
                  <span class="text-span">
                    Flexibility</span>
                </div>
              <div class="text">
            Access to ordered/saved labels and easy reordering at any time</div>
        </div>
      <div class="sortimo-dark-hover highlight-item sortimo-blue-link">
          <div class="component-headline">
                  <span class="icon-span"><svg id="" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35"><defs><style>.icon-produkthighlights-check-cls-1{fill:#546373;}.icon-produkthighlights-check-cls-2{fill:#fff;}</style></defs><title>icon-produkthighlights-check</title><circle class="icon-produkthighlights-check-cls-1" cx="17.5" cy="17.5" r="17.5"></circle><path class="icon-produkthighlights-check-cls-2" d="M-33.71-3.63a1.49,1.49,0,0,0-2.1,0h0l-8.83,9.52L-47.8,2.29a1.47,1.47,0,0,0-2.07-.17h0A1.54,1.54,0,0,0-50,4.27l4.23,4.91a1.48,1.48,0,0,0,1.09.52h0a1.52,1.52,0,0,0,1.08-.48l10-10.69A1.56,1.56,0,0,0-33.71-3.63Z" transform="translate(59.33 14.77)"></path></svg></span>
                  <span class="text-span">
                    Visualisation</span>
                </div>
              <div class="text">
            3D visualisation of the van racking system makes it easier to select label design, colour and arrangement</div>
        </div>
      </div>
    <div class="image" style="background-image: url('images/product/arbeitsplatzorga-labels-aftersales-produkthighlights.jpg');">
      <img src="images/product/arbeitsplatzorga-labels-aftersales-produkthighlights.jpg" style="visibility: hidden;">
    </div>
    <div class="left-text-responsive">
      <div class="sortimo-dark-hover highlight-item sortimo-blue-link">
          <div class="component-headline">
                  <span class="icon-span"><svg id="" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35"><defs><style>.icon-produkthighlights-check-cls-1{fill:#546373;}.icon-produkthighlights-check-cls-2{fill:#fff;}</style></defs><title>icon-produkthighlights-check</title><circle class="icon-produkthighlights-check-cls-1" cx="17.5" cy="17.5" r="17.5"></circle><path class="icon-produkthighlights-check-cls-2" d="M-33.71-3.63a1.49,1.49,0,0,0-2.1,0h0l-8.83,9.52L-47.8,2.29a1.47,1.47,0,0,0-2.07-.17h0A1.54,1.54,0,0,0-50,4.27l4.23,4.91a1.48,1.48,0,0,0,1.09.52h0a1.52,1.52,0,0,0,1.08-.48l10-10.69A1.56,1.56,0,0,0-33.71-3.63Z" transform="translate(59.33 14.77)"></path></svg></span>
                  <span class="text-span">
                    Intuitive operation</span>
                </div>
              <div class="text">
            <p>Easy creation of labels in a just few clicks </p></div>
        </div>
      <div class="sortimo-dark-hover highlight-item sortimo-blue-link">
          <div class="component-headline">
                  <span class="icon-span"><svg id="" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35"><defs><style>.icon-produkthighlights-check-cls-1{fill:#546373;}.icon-produkthighlights-check-cls-2{fill:#fff;}</style></defs><title>icon-produkthighlights-check</title><circle class="icon-produkthighlights-check-cls-1" cx="17.5" cy="17.5" r="17.5"></circle><path class="icon-produkthighlights-check-cls-2" d="M-33.71-3.63a1.49,1.49,0,0,0-2.1,0h0l-8.83,9.52L-47.8,2.29a1.47,1.47,0,0,0-2.07-.17h0A1.54,1.54,0,0,0-50,4.27l4.23,4.91a1.48,1.48,0,0,0,1.09.52h0a1.52,1.52,0,0,0,1.08-.48l10-10.69A1.56,1.56,0,0,0-33.71-3.63Z" transform="translate(59.33 14.77)"></path></svg></span>
                  <span class="text-span">
                    Flexibility</span>
                </div>
              <div class="text">
            Access to ordered/saved labels and easy reordering at any time</div>
        </div>
      <div class="sortimo-dark-hover highlight-item sortimo-blue-link">
          <div class="component-headline">
                  <span class="icon-span"><svg id="" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35"><defs><style>.icon-produkthighlights-check-cls-1{fill:#546373;}.icon-produkthighlights-check-cls-2{fill:#fff;}</style></defs><title>icon-produkthighlights-check</title><circle class="icon-produkthighlights-check-cls-1" cx="17.5" cy="17.5" r="17.5"></circle><path class="icon-produkthighlights-check-cls-2" d="M-33.71-3.63a1.49,1.49,0,0,0-2.1,0h0l-8.83,9.52L-47.8,2.29a1.47,1.47,0,0,0-2.07-.17h0A1.54,1.54,0,0,0-50,4.27l4.23,4.91a1.48,1.48,0,0,0,1.09.52h0a1.52,1.52,0,0,0,1.08-.48l10-10.69A1.56,1.56,0,0,0-33.71-3.63Z" transform="translate(59.33 14.77)"></path></svg></span>
                  <span class="text-span">
                    Visualisation</span>
                </div>
              <div class="text">
            3D visualisation of the van racking system makes it easier to select label design, colour and arrangement</div>
        </div>
      </div>
    <div class="right-text">
      <div class="sortimo-dark-hover highlight-item sortimo-blue-link">
           
      <div class="component-headline ">
        
          <svg id="" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35"><defs><style>.icon-produkthighlights-check-cls-1{fill:#546373;}.icon-produkthighlights-check-cls-2{fill:#fff;}</style></defs><title>icon-produkthighlights-check</title><circle class="icon-produkthighlights-check-cls-1" cx="17.5" cy="17.5" r="17.5"></circle><path class="icon-produkthighlights-check-cls-2" d="M-33.71-3.63a1.49,1.49,0,0,0-2.1,0h0l-8.83,9.52L-47.8,2.29a1.47,1.47,0,0,0-2.07-.17h0A1.54,1.54,0,0,0-50,4.27l4.23,4.91a1.48,1.48,0,0,0,1.09.52h0a1.52,1.52,0,0,0,1.08-.48l10-10.69A1.56,1.56,0,0,0-33.71-3.63Z" transform="translate(59.33 14.77)"></path></svg>&nbsp;
        
        Price transparency
      </div>
    
    
  
<div class="text">
            <p>Full cost control thanks to dynamic price display during configuration</p></div>
        </div>
      <div class="sortimo-dark-hover highlight-item sortimo-blue-link">
              
    
      <div class="component-headline ">
        
          <svg id="" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35"><defs><style>.icon-produkthighlights-check-cls-1{fill:#546373;}.icon-produkthighlights-check-cls-2{fill:#fff;}</style></defs><title>icon-produkthighlights-check</title><circle class="icon-produkthighlights-check-cls-1" cx="17.5" cy="17.5" r="17.5"></circle><path class="icon-produkthighlights-check-cls-2" d="M-33.71-3.63a1.49,1.49,0,0,0-2.1,0h0l-8.83,9.52L-47.8,2.29a1.47,1.47,0,0,0-2.07-.17h0A1.54,1.54,0,0,0-50,4.27l4.23,4.91a1.48,1.48,0,0,0,1.09.52h0a1.52,1.52,0,0,0,1.08-.48l10-10.69A1.56,1.56,0,0,0-33.71-3.63Z" transform="translate(59.33 14.77)"></path></svg>&nbsp;
        
        Optimum result
      </div>
    
    
  
<div class="text">
            Predefined icons can be incorporated and your own graphics uploaded for the perfect look </div>
        </div>
      <div class="sortimo-dark-hover highlight-item sortimo-blue-link">
         <div class="component-headline ">
        
          <svg id="" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewBox="0 0 35 35"><defs><style>.icon-produkthighlights-check-cls-1{fill:#546373;}.icon-produkthighlights-check-cls-2{fill:#fff;}</style></defs><title>icon-produkthighlights-check</title><circle class="icon-produkthighlights-check-cls-1" cx="17.5" cy="17.5" r="17.5"></circle><path class="icon-produkthighlights-check-cls-2" d="M-33.71-3.63a1.49,1.49,0,0,0-2.1,0h0l-8.83,9.52L-47.8,2.29a1.47,1.47,0,0,0-2.07-.17h0A1.54,1.54,0,0,0-50,4.27l4.23,4.91a1.48,1.48,0,0,0,1.09.52h0a1.52,1.52,0,0,0,1.08-.48l10-10.69A1.56,1.56,0,0,0-33.71-3.63Z" transform="translate(59.33 14.77)"></path></svg>&nbsp;
        
        Save time and money
      </div>
    
    
  
<div class="text">
            <p>Save time and money by printing at a specialist</p></div>
        </div>
      </div>
  </div>
</div>
</div>
















</div>




<!-- END -->







    </div>
  </section>




<!--***************************************-->
<?php include'pr-sl-n.php';?>

<!--***************************************-->

<section id="lalla">
    <div class="container-fluid xcfaSDZfca">
      <div class="row ">
        <div class="yCmsComponent sortimo-component-slot clearfix">
<div id="comp_00002T3L" class="sortimo-component text-component big-header
">
  
      <h3 class="component-headline ">
        
        Labels for Globelyst4
      </h3>
    
  
</div></div>

<div class="yCmsComponent sortimo-component-slot clearfix">
<div id="comp_00002TUS" class="sortimo-component text-component small-header
">
   <h3 class="component-headline ">
        
        Clearer arrangement in your <b>Globelyst4</b>
      </h3>
    
    
    
  
<div class="text">
      <p>For the Globelyst4, we provide you with a PDF template which can be individually and conveniently labelled and printed. BOXXes and drawers for the Globelyst4 are then quickly and legibly labelled.</p><p>The adhesive labels are made of tear-resistant and moisture-resistant material and are highly durable thanks to their strong adhesion.</p><p>You can order the self-adhesive sheet for printing the labels&nbsp;<a>here</a>. Just select the sheets with the coloured strips that suit your needs.&nbsp;</p></div>
  </div></div>


<div class="yCmsComponent sortimo-component-slot clearfix">
<div id="comp_00002TUT" class="sortimo-component text-component small-header
">
  
      <h1 class="component-headline ">
        
        Downloads
      </h1>
    
    
      <div class="component-headline subheadline">
        
        Labelling templates for BOXXes, cases and insetboxes
      </div>
    
    
  
</div></div>
<div class="yCmsComponent sortimo-component-slot clearfix">
<div class="sortimo-component download-component" id="comp_00002TUU">
  <div class="download-item" onclick="window.open('images/product/mySortimo-labels-BOXXen-Koffer.pdf', '_blank');">
      <div class="download-image">
        <img src="images/product/mySortimo-labels-BOXXen-Koffer.jpg" class="image">
      </div>
      <div class="download-text">
        <div class="text-arrow"></div>
        <div class="text-container">
          <div class="name">Labelling templates for BOXXes and cases</div>
          <div class="info">
            <div class="size">
                65&nbsp;KB</div>
            <div class="icon">
              <svg version="1.1" id="Ebene_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30px" height="49px" viewBox="0 0 20 32" style="enable-background: new 0 0 20 32;" xml:space="preserve">
                <style type="text/css">
                .st0 {
                  fill: #0068b4;
                }
                
                .st1 {
                  fill: #FFFFFF;
                }
                </style>
                <g>
                  <g>
                    <path class="st0" d="M12.5,7.1V0.2L1,0.1c-0.2,0-0.4,0.2-0.4,0.4v22.1C0.6,22.9,0.8,23,1,23h5.5l0-5l7.1,0l0,5h5.5
                      c0.2,0,0.4-0.2,0.4-0.4l0-15.6L12.5,7.1z"></path>
                    <polygon class="st0" points="19.5,6 13.7,6 13.7,0.2     "></polygon>
                  </g>
                  <g>
                    <path class="st1" d="M3.9,10.7h1.9c0.2,0,0.4,0,0.6,0.1c0.2,0.1,0.4,0.2,0.6,0.3c0.2,0.1,0.3,0.3,0.4,0.5c0.1,0.2,0.2,0.5,0.2,0.8
                      c0,0.4-0.1,0.8-0.4,1.1c-0.3,0.3-0.7,0.5-1.2,0.5H4.7V16H3.9V10.7z M4.7,13.2h1.2c0.3,0,0.5-0.1,0.7-0.3c0.1-0.2,0.2-0.4,0.2-0.6
                      c0-0.2,0-0.3-0.1-0.5c-0.1-0.1-0.1-0.2-0.2-0.3c-0.2-0.1-0.3-0.2-0.6-0.2H4.7V13.2z"></path>
                    <path class="st1" d="M8.3,10.7h1.8c0.7,0,1.2,0.3,1.6,0.9c0.1,0.2,0.2,0.4,0.2,0.6c0,0.2,0,0.6,0,1.1c0,0.6,0,1-0.1,1.2
                      c0,0.1,0,0.2-0.1,0.3c0,0.1-0.1,0.2-0.1,0.3c-0.2,0.3-0.4,0.5-0.6,0.6c-0.3,0.2-0.6,0.3-1,0.3H8.3V10.7z M9.1,15.3h0.9
                      c0.4,0,0.8-0.2,1-0.5c0.1-0.1,0.1-0.3,0.2-0.4c0-0.2,0-0.5,0-1c0-0.5,0-0.8,0-1c0-0.2-0.1-0.4-0.2-0.5c-0.2-0.3-0.5-0.5-0.9-0.5
                      H9.1V15.3z"></path>
                    <path class="st1" d="M13.1,10.7h3.3v0.8h-2.5V13H16v0.7h-2.2V16h-0.8V10.7z"></path>
                  </g>
                  <polygon class="st0" points="12.5,24.1 12.5,19.1 7.6,19.1 7.6,24.1 3.6,24.1 10,31.4 16.6,24.1   "></polygon>
                </g>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  <div class="download-item" onclick="window.open('images/product/mySortimo-labels-Insetboxen-EN.pdf', '_blank');">
      <div class="download-image">
        <img src="images/product/mySortimo-labels-Insetboxen-EN.jpg" class="image">
      </div>
      <div class="download-text">
        <div class="text-arrow"></div>
        <div class="text-container">
          <div class="name">Labelling templates for BOXXes for insetboxes</div>
          <div class="info">
            <div class="size">
                670&nbsp;KB</div>
            <div class="icon">
              <svg version="1.1" id="Ebene_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30px" height="49px" viewBox="0 0 20 32" style="enable-background: new 0 0 20 32;" xml:space="preserve">
                <style type="text/css">
                .st0 {
                  fill: #0068b4;
                }
                
                .st1 {
                  fill: #FFFFFF;
                }
                </style>
                <g>
                  <g>
                    <path class="st0" d="M12.5,7.1V0.2L1,0.1c-0.2,0-0.4,0.2-0.4,0.4v22.1C0.6,22.9,0.8,23,1,23h5.5l0-5l7.1,0l0,5h5.5
                      c0.2,0,0.4-0.2,0.4-0.4l0-15.6L12.5,7.1z"></path>
                    <polygon class="st0" points="19.5,6 13.7,6 13.7,0.2     "></polygon>
                  </g>
                  <g>
                    <path class="st1" d="M3.9,10.7h1.9c0.2,0,0.4,0,0.6,0.1c0.2,0.1,0.4,0.2,0.6,0.3c0.2,0.1,0.3,0.3,0.4,0.5c0.1,0.2,0.2,0.5,0.2,0.8
                      c0,0.4-0.1,0.8-0.4,1.1c-0.3,0.3-0.7,0.5-1.2,0.5H4.7V16H3.9V10.7z M4.7,13.2h1.2c0.3,0,0.5-0.1,0.7-0.3c0.1-0.2,0.2-0.4,0.2-0.6
                      c0-0.2,0-0.3-0.1-0.5c-0.1-0.1-0.1-0.2-0.2-0.3c-0.2-0.1-0.3-0.2-0.6-0.2H4.7V13.2z"></path>
                    <path class="st1" d="M8.3,10.7h1.8c0.7,0,1.2,0.3,1.6,0.9c0.1,0.2,0.2,0.4,0.2,0.6c0,0.2,0,0.6,0,1.1c0,0.6,0,1-0.1,1.2
                      c0,0.1,0,0.2-0.1,0.3c0,0.1-0.1,0.2-0.1,0.3c-0.2,0.3-0.4,0.5-0.6,0.6c-0.3,0.2-0.6,0.3-1,0.3H8.3V10.7z M9.1,15.3h0.9
                      c0.4,0,0.8-0.2,1-0.5c0.1-0.1,0.1-0.3,0.2-0.4c0-0.2,0-0.5,0-1c0-0.5,0-0.8,0-1c0-0.2-0.1-0.4-0.2-0.5c-0.2-0.3-0.5-0.5-0.9-0.5
                      H9.1V15.3z"></path>
                    <path class="st1" d="M13.1,10.7h3.3v0.8h-2.5V13H16v0.7h-2.2V16h-0.8V10.7z"></path>
                  </g>
                  <polygon class="st0" points="12.5,24.1 12.5,19.1 7.6,19.1 7.6,24.1 3.6,24.1 10,31.4 16.6,24.1   "></polygon>
                </g>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div></div>


<br>
<div class="yCmsComponent sortimo-component-slot clearfix">
<div id="comp_00002TUV" class="sortimo-component text-component big-header
">
  <div class="text">
      <p><strong>To label the templates</strong>, click with the right mouse button on the download button and select the input "<strong>Save target as ...</strong>". To save the PDF file on your computer and label it individually.</p><p><strong>IMPORTANT NOTE</strong>: When printing the label sheets, please select "Actual size" in the print menu under "Customize Page and Options"!</p></div>
  </div></div>

<br>
<br>
<br>



</div>
</div>
</section>

    
    <?php include'footer.php';?>


    


</body>
</html>

