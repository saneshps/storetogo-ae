
<!DOCTYPE html>
<html lang="en">
<head>
<!--***************************************-->
<script src="js/bootstrap.min.js" ></script>
<!--***************************************-->


	<title>StoreToGo Dubai UAE</title>
	<!-- <meta name="description" content="Floors born tough, our floor tiles are Strong, Durable & Aesthetic.  Our product applications can be used in diverse segment from Industries, Warehouses to Stables, from Gymnasiums, Hospitals, Swimming pool, Garage, Exhibitions to Events the list goes on. Our portfolio includes PVC tiles, Heavy Duty Tiles, Work-Station Mats, Ergonomic Anti-Fatigue mats, Entrance floor matting, Outdoor tiles and Sports tiles. Contact stroetogofloor.ae Sharjah, UAE for more information."> -->
	<link rel="shortcut icon" href="images/favicon.png">
	<meta charset="utf-8">
	<meta name="keywords" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="canonical" href="" />
	

<!--***************************************-->
<!-- FONT --> 

  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic" />
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Montserrat:400,700" />
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700">  
      
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700"> 
<!--***************************************-->

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<!-- CSS  ***************************************-->		  
	<link rel="stylesheet" href="css/bootstrap.min.css" >

  <link rel="stylesheet" href="css/prod-style.css" >
	<link rel="stylesheet" href="css/layout.css" >
	<link rel="stylesheet" href="css/home.css" >
  <link rel="stylesheet" href="css/testim.css" >
  <link rel="stylesheet" href="css/product.css" >
<!--***************************************-->




</head>
<body>


<?php $page ='product';  include'header.php';?>

<!-- EMAIL -->
<?php $page ='product';  include'express.php';?>
<!-- EMAIL -->

<section class="page-pro">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <h4><a href="index.php">Home</a> > sContainer: pallet-format service depot</h4>
      </div>
    </div>
  </div>
  
</section>


 <section id="serico-hg" style="padding-bottom: 0px">
    <div class="container-fluid">

<!-- STRT -->
<div class="row sty-wid">
<div class="yCmsComponent sortimo-component-slot clearfix">
<div id="comp_00002567" class="sortimo-component text-component big-header
">
  
      <h1 class="component-headline ">
        
        sContainer <br> The customisable service depot in pallet format!!
      </h1>
      
<div class="text">
      <p style="text-align: center;">Thanks to its basic Euro pallet dimensions the sContainer fits in perfectly with every standardised transport and logistics chain. Mounting fixtures for common material handling equipment ensure simple handling, thus also making the Service Container ideal for global usage. The option of equipping the container with the SR5 racking system turns this mobile depot into an organisational system at any construction site or service assignment – and with a minimal footprint as well. The sContainer also provides a large area for company logos or advertising graphics, which we would be happy to create for you or which you can order yourself using the StoreToGo graphics sticker configurator. Your storage space then offers the added advantage of acting as a perfect, low-cost advertising medium.</p>

<p style="text-align: center;">&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;You can easily order the sContainer online or contact our StoreToGo experts for advice.</p>
</div>
 
  </div></div>

</div>

</div>
</section>


<section id="serico">
  <div class="container-fluid">
  
  <div class="yCmsComponent sortimo-component-slot clearfix centet-all">
<div class="sortimo-component tile-component vuidjb" id="">
  <div class="low single-tile wide" style="background-image: url('images/product/sContainer-kacheln-2-groessen-690x340.jpg'); ">
      <div class="sortimo-animate sortimo-tile-from-right" style="display: block;">
          <div class="text">
            <div class="align-container">
              

      <div class="component-headline ">
        
        sContainer
      </div>
    
    
  
<hr>
                <p class="tile-text">
                With just a few clicks, you can easily order the sContainer online in two different heights.</p>
            </div>
          </div>
        </div>
      </div>
  <div class="low single-tile wide" style="background-image: url('images/product/sContainer-kacheln-zubehoer-690x340.jpg'); ">
      <div class="sortimo-animate sortimo-tile-from-left" style="display: block;">
          <div class="text">
            <div class="align-container">
              
      <div class="component-headline ">
        
        sContainer accessories
      </div>
    
<hr>
                <p class="tile-text">
                Accessories such as crane eyes let you adapt your sContainer to your personal requirements.</p>
            </div>
          </div>
        </div>
      </div>
  </div></div>
   

</div></section>



 <section id="serico-hg" >
    <div class="container-fluid">

<!-- STRT -->
<div class="row sty-wid1">

<div class="yCmsComponent sortimo-component-slot clearfix">
<div class="sortimo-component anchor-component" id="cmsitem_00009002">
  <div class="anchor-item" onclick="window.open('#comp_0000257W','_self');">
      <div class="icon">
        <svg id="icon_anchor-features-im-detail-auge" xmlns="http://www.w3.org/2000/svg" width="38" height="28" viewBox="0 0 38 28"><title>icon_anchor-features-im-detail-auge</title><path class="icon_anchor-features-im-detail-auge-cls-1" d="M26.24,33.2c-10.4,0-19-9.27-19-14,0-2.56,2.25-6.07,5.72-8.93A21.38,21.38,0,0,1,26.24,5.2c10.2,0,19,9.39,19,14,0,1.94-1.77,5.39-5.71,8.72C37.2,29.89,32.37,33.2,26.24,33.2Zm0-24.58c-9.07,0-15.81,8.1-15.81,10.58s6.74,10.57,15.81,10.57c5.17,0,9.31-2.85,11.32-4.55,3.13-2.65,4.49-5.27,4.49-6s-1.32-3.41-4.48-6.08C35.56,11.44,31.43,8.62,26.24,8.62Z" transform="translate(-7.24 -5.2)"></path><path class="icon_anchor-features-im-detail-auge-cls-1" d="M26.24,7.48c-4.88,0-8.84,4.32-8.84,9.64s4,9.65,8.84,9.65,8.83-4.32,8.83-9.65H26.24Z" transform="translate(-7.24 -5.2)"></path></svg></div>
      <div class="text">
        Product Details</div>
    </div>
  <div class="anchor-item" onclick="window.open('#00009006_textComponent','_self');">
      <div class="icon">
        <svg id="icon-anchor-sr5-komponenten" xmlns="http://www.w3.org/2000/svg" width="28" height="27" viewBox="0 0 28 27"><defs><style>.icon-anchor-sr5-komponenten-cls-1{fill:#fff;}</style></defs><title>icon-anchor-sr5-komponenten</title><path class="icon-anchor-sr5-komponenten-cls-1" d="M71.37,43.09c-1,0-1.26.59-1.26.59v2.48h-23V43.69a1.24,1.24,0,0,0-1.23-.6c-1,0-1.25.6-1.25.6v26.4h2.48V64.85h23v5.23H72.6V43.68A1.24,1.24,0,0,0,71.37,43.09Zm-1.26,5.83v3.82h-23V48.92ZM60.92,60.36H56.44l-1-1.11H62Zm-13.84-2V55.24h23v3.14Z" transform="translate(-44.6 -43.09)"></path></svg></div>
      <div class="text">
        Interior equipment</div>
    </div>
  <div class="anchor-item" onclick="window.open('#00009009_textComponent','_self');">
      <div class="icon">
        <svg id="icon-anchor-werbung" xmlns="http://www.w3.org/2000/svg" width="35" height="35.01" viewBox="0 0 35 35.01"><defs><style>.icon-anchor-werbung-cls-1{fill:#fff;}</style></defs><path class="icon-anchor-werbung-cls-1" d="M33.36,30.41a1,1,0,0,0-1,.51,3.15,3.15,0,0,0-.3,1.54v1.4a3.09,3.09,0,0,0,.3,1.56,1.07,1.07,0,0,0,1,.49,1,1,0,0,0,.93-.46,2.8,2.8,0,0,0,.31-1.5v-1.4a3.25,3.25,0,0,0-.3-1.6A1,1,0,0,0,33.36,30.41Z" transform="translate(-20.05 -19.99)"></path><path class="icon-anchor-werbung-cls-1" d="M46.69,35.91a1,1,0,0,0,.94-.46,3,3,0,0,0,.31-1.5v-1.4a3.25,3.25,0,0,0-.31-1.6,1,1,0,0,0-.93-.53,1,1,0,0,0-.94.51,3.11,3.11,0,0,0-.31,1.54v1.4a3,3,0,0,0,.31,1.54A1,1,0,0,0,46.69,35.91Z" transform="translate(-20.05 -19.99)"></path><path class="icon-anchor-werbung-cls-1" d="M37.54,20a17.52,17.52,0,0,0-1,35L54.81,40.37a17,17,0,0,0,.24-2.85A17.53,17.53,0,0,0,37.55,20Zm6.27,12.57A3.88,3.88,0,0,1,44.57,30a2.6,2.6,0,0,1,2.11-.94,2.64,2.64,0,0,1,2.1.91,3.84,3.84,0,0,1,.77,2.55v1.37a3.73,3.73,0,0,1-.75,2.49,3,3,0,0,1-4.21,0,3.63,3.63,0,0,1-.78-2.46Zm-6.54-.06A4,4,0,0,1,38,30a2.57,2.57,0,0,1,2.1-.89,2.74,2.74,0,0,1,2,.64,3,3,0,0,1,.76,2H41.24a1.92,1.92,0,0,0-.31-1,1,1,0,0,0-.79-.28,1.07,1.07,0,0,0-.94.47,3.05,3.05,0,0,0-.3,1.52v1.44a3,3,0,0,0,.32,1.58,1.19,1.19,0,0,0,1.08.5,1.49,1.49,0,0,0,.77-.19l.14-.1V34.17H40.07V33h2.74v3.27a3,3,0,0,1-1.14.76,4.15,4.15,0,0,1-1.48.25,2.68,2.68,0,0,1-2.13-.85,3.63,3.63,0,0,1-.79-2.47Zm-7.2,4.65H25.62v-8h1.61v6.65h2.84Zm3.33.1a2.62,2.62,0,0,1-2.13-.88,3.68,3.68,0,0,1-.78-2.46V32.56A4,4,0,0,1,31.25,30a2.86,2.86,0,0,1,4.21,0,3.9,3.9,0,0,1,.78,2.55v1.37a3.8,3.8,0,0,1-.76,2.49,2.62,2.62,0,0,1-2.1.88ZM35.48,54A17.52,17.52,0,0,1,52.76,39.29c.32,0,.64,0,1,0Z" transform="translate(-20.05 -19.99)"></path></svg></div>
      <div class="text">
        Design of advertisement</div>
    </div>
  <div class="anchor-item" onclick="window.open('#00009011_textComponent','_self');">
      <div class="icon">
        <svg id="icon-anchor-broschuere-download" xmlns="http://www.w3.org/2000/svg" width="20" height="34" viewBox="0 0 20 34"><defs><style>.icon-anchor-broschuere-download-cls-1{fill:#fff;}</style></defs><title>icon-anchor-broschuere-download</title><path class="icon-anchor-broschuere-download-cls-1" d="M-17.5-59.33h-5v-5Zm-7.41,1.87V-64.7l-12.17-.1a.45.45,0,0,0-.42.42v23.17a.39.39,0,0,0,.42.42H-33V-47H-22v6.24h4.12a.45.45,0,0,0,.42-.42V-57.46Zm0,19v-5.24h-5.18v5.24h-4.24l6.78,7.65,7-7.65Z" transform="translate(37.5 64.8)"></path></svg></div>
      <div class="text">
        Brochure</div>
    </div>
  </div></div>

</div>
<!-- END -->

<!-- STRT -->
<div class="row sty-wid">
 
 <div class="yCmsComponent sortimo-component-slot clearfix">
<div id="comp_0000257W" class="sortimo-component text-component big-header
">
      
      <div class="component-headline ">
        
        sContainer – just convenient
      </div>
    
    
    
      <div class="component-headline subheadline">
        
        Individual, mobile, neat and offering lots of space: the sContainer is the flexible friend for service technicians, tradespeople and construction workers 
      </div>
    
</div></div>

</div>
<!-- END -->


</div></section>

 <?php include'pr-sl-n-con.php';?>









 <section id="serico-hg" >
    <div class="container-fluid">



<!-- STRT -->
<div class="row sty-wid1">
<div class="yCmsComponent sortimo-component-slot clearfix">
<div id="comp_0000257Z" class="sortimo-component text-component big-header
">
      <div class="component-headline ">
        
        Guaranteed to meet your requirements!
      </div>
    
<div class="text">
      <p style="text-align: center;">The service containers offer practical benefits in various situations, enabling you to significantly boost your added value chain.</p></div>
  </div></div>
</div>
<!-- END -->


<!-- STRT -->
<div class="row sty-wid1">
<div class="yCmsComponent sortimo-component-slot clearfix">
<div class="sortimo-component tooltip-component" id="comp_0000257Y">
  <div class="image-container" style="background-image: url(images/product/sContainer-tooltip.jpg); height: auto; background-size: cover;">
    <input type="hidden" class="orginalImageWidth" value="1390">
    <input type="hidden" class="responsiveImageScale" value="">
    
    <img src="images/product/sContainer-tooltip.jpg" class="hidden-image">
    <div class="tooltip-item tooltip-cd-pulse" style="top: 305px; left: 245px" onclick="showTooltipItem('00009000_tooltipItem');">
        <input type="hidden" class="orginalItemLeft" value="245">
        <input type="hidden" class="orginalItemTop" value="305">
        1</div>
      <div class="tooltip-overlay" id="00009000_tooltipItem" style="display: none;">
        <div class="tooltip-content">
          <div class="close-tooltip">
            <span class="glyphicon glyphicon-remove"></span>
          </div>
          <div class="tooltip-image-container">
              <img src="images/product/sContainer-tooltip-kranoesen.gif" class="tooltip-image">
            </div>
            <div class="tooltip-image-arrow"></div>
          <div class="tooltip-text-container">
            <div class="tooltip-index">
              1</div>
            <div class="tooltip-header">
              
    
      <div class="component-headline headline">
        
        Lifting eyes
      </div>
    
</div>
            <div class="tooltip-text">
              The eyelets can be optionally retrofitted in order to be able to move the sContainer on site with the crane.</div>
            </div>
        </div>
      </div>
    <div class="tooltip-item tooltip-cd-pulse" style="top: 360px; left: 452px" onclick="showTooltipItem('00009002_tooltipItem');">
        <input type="hidden" class="orginalItemLeft" value="452">
        <input type="hidden" class="orginalItemTop" value="360">
        2</div>
      <div class="tooltip-overlay" id="00009002_tooltipItem" style="display: none;">
        <div class="tooltip-content">
          <div class="close-tooltip">
            <span class="glyphicon glyphicon-remove"></span>
          </div>
          <div class="tooltip-image-container">
              <img src="images/product/sContainer-tooltip-schloss.gif" class="tooltip-image">
            </div>
            <div class="tooltip-image-arrow"></div>
          <div class="tooltip-text-container">
            <div class="tooltip-index">
              2</div>
            <div class="tooltip-header">
              
      <div class="component-headline headline">
        
        Lock
      </div>
    
</div>
            <div class="tooltip-text">
              <p>You can choose from three locks for your sContainer. The most cost-effective option is a padlock, which provides solid anti-theft prevention. Alternatively, you can opt for a cylinder lock or even the high-end version, an electronic lock, which means that you have no need for keys.&nbsp;&nbsp;</p></div>
            </div>
        </div>
      </div>
    <div class="tooltip-item tooltip-cd-pulse" style="top: 540px; left: 520px" onclick="showTooltipItem('00009001_tooltipItem');">
        <input type="hidden" class="orginalItemLeft" value="520">
        <input type="hidden" class="orginalItemTop" value="540">
        3</div>
      <div class="tooltip-overlay" id="00009001_tooltipItem" style="display: none;">
        <div class="tooltip-content">
          <div class="close-tooltip">
            <span class="glyphicon glyphicon-remove"></span>
          </div>
          <div class="tooltip-image-container">
              <img src="images/product/sContainer-tooltip-beklebung.jpg" class="tooltip-image">
            </div>
            <div class="tooltip-image-arrow"></div>
          <div class="tooltip-text-container">
            <div class="tooltip-index">
              3</div>
            <div class="tooltip-header">
              
      <div class="component-headline headline">
        
        Decal surface
      </div>
    
</div>
            <div class="tooltip-text">
              <p>The side panels of the sContainer provide an excellent advertising surface for your company. The StoreToGo graphics configurator lets you design and order the decals for your sContainer directly yourself – one-stop ordering and delivery.&nbsp;Simply select "StoreToGo" from the manufacturer and off you go!</p>
</div>
            </div>
        </div>
      </div>
    <div class="tooltip-item tooltip-cd-pulse" style="top: 695px; left: 305px" onclick="showTooltipItem('00009003_tooltipItem');">
        <input type="hidden" class="orginalItemLeft" value="305">
        <input type="hidden" class="orginalItemTop" value="695">
        4</div>
      <div class="tooltip-overlay" id="00009003_tooltipItem" style="display: none;">
        <div class="tooltip-content">
          <div class="close-tooltip">
            <span class="glyphicon glyphicon-remove"></span>
          </div>
          <div class="tooltip-image-container">
              <img src="images/product/sContainer-tooltip-transport.jpg" class="tooltip-image">
            </div>
            <div class="tooltip-image-arrow"></div>
          <div class="tooltip-text-container">
            <div class="tooltip-index">
              4</div>
            <div class="tooltip-header">
              
      <div class="component-headline headline">
        
        Lifting lugs
      </div>
    
</div>
            <div class="tooltip-text">
              <p>The lugs can optionally be retrofitted to allow the sContainer to be moved by crane on site as well.</p></div>
            </div>
        </div>
      </div>
    <div class="tooltip-item tooltip-cd-pulse" style="top: 210px; left: 652px" onclick="showTooltipItem('00011000_tooltipItem');">
        <input type="hidden" class="orginalItemLeft" value="652">
        <input type="hidden" class="orginalItemTop" value="210">
        5</div>
      <div class="tooltip-overlay" id="00011000_tooltipItem" style="display: none;">
        <div class="tooltip-content">
          <div class="close-tooltip">
            <span class="glyphicon glyphicon-remove"></span>
          </div>
          <div class="tooltip-image-container">
              <img src="images/product/sContainer-tooltip-groessen.jpg" class="tooltip-image">
            </div>
            <div class="tooltip-image-arrow"></div>
          <div class="tooltip-text-container">
            <div class="tooltip-index">
              5</div>
            <div class="tooltip-header">
              
      <div class="component-headline headline">
        
        Height
      </div>
    
    
  
</div>
            <div class="tooltip-text">
              <p>The sContainer is available in two different heights. The lower height (1,200 mm) is even suitable for transporting in lightweight vans. The taller version (1,900 mm) naturally offers you even more storage space in the interior of the container.</p>
</div>
            </div>
        </div>
      </div>
    <div class="tooltip-item tooltip-cd-pulse" style="top: 310px; left: 820px" onclick="showTooltipItem('00010001_tooltipItem');">
        <input type="hidden" class="orginalItemLeft" value="820">
        <input type="hidden" class="orginalItemTop" value="310">
        6</div>
      <div class="tooltip-overlay" id="00010001_tooltipItem" style="display: none;">
        <div class="tooltip-content">
          <div class="close-tooltip">
            <span class="glyphicon glyphicon-remove"></span>
          </div>
          <div class="tooltip-image-container">
              <img src="images/product/sContainer-tooltip-innenraum.jpg" class="tooltip-image">
            </div>
            <div class="tooltip-image-arrow"></div>
          <div class="tooltip-text-container">
            <div class="tooltip-index">
              6</div>
            <div class="tooltip-header">
                  
      <div class="component-headline headline">
        
        Interior
      </div>
      
</div>
            <div class="tooltip-text">
              The interior is conveniently accessed through a large door. A hard-wearing SoboGrip floor is used as the base. What is unique is the fact that SR5 van racking components are fitted in the interior to ensure optimum organisation and also load securing.</div>
            </div>
        </div>
      </div>
    <div class="tooltip-item tooltip-cd-pulse" style="top: 63px; left: 900px" onclick="showTooltipItem('00010000_tooltipItem');">
        <input type="hidden" class="orginalItemLeft" value="900">
        <input type="hidden" class="orginalItemTop" value="63">
        7</div>
      <div class="tooltip-overlay" id="00010000_tooltipItem" style="display: none;">
        <div class="tooltip-content">
          <div class="close-tooltip">
            <span class="glyphicon glyphicon-remove"></span>
          </div>
          <div class="tooltip-image-container">
              <img src="images/product/sContainer-tooltip-material.jpg" class="tooltip-image">
            </div>
            <div class="tooltip-image-arrow"></div>
          <div class="tooltip-text-container">
            <div class="tooltip-index">
              7</div>
            <div class="tooltip-header">
              
      <div class="component-headline headline">
        
        Durable material
      </div>
    
</div>
            <div class="tooltip-text">
              A massive frame forms the base, which permits a load capacity of up to 500 kg. The cladding is made of powder-coated sheet steel. A plastic cover reliably prevents the ingress of rainwater.</div>
            </div>
        </div>
      </div>
    </div>
  <div class="mobile-section">
    <div class="header-tabs">
      <div class="header-tab active" id="00009000_tooltipItem_header_tab" onclick="switchTooltipTab(this); return false;">
          <div class="tooltip-index">
            1</div>
        </div>
      <div class="header-tab" id="00009002_tooltipItem_header_tab" onclick="switchTooltipTab(this); return false;">
          <div class="tooltip-index">
            2</div>
        </div>
      <div class="header-tab" id="00009001_tooltipItem_header_tab" onclick="switchTooltipTab(this); return false;">
          <div class="tooltip-index">
            3</div>
        </div>
      <div class="header-tab" id="00009003_tooltipItem_header_tab" onclick="switchTooltipTab(this); return false;">
          <div class="tooltip-index">
            4</div>
        </div>
      <div class="header-tab" id="00011000_tooltipItem_header_tab" onclick="switchTooltipTab(this); return false;">
          <div class="tooltip-index">
            5</div>
        </div>
      <div class="header-tab" id="00010001_tooltipItem_header_tab" onclick="switchTooltipTab(this); return false;">
          <div class="tooltip-index">
            6</div>
        </div>
      <div class="header-tab" id="00010000_tooltipItem_header_tab" onclick="switchTooltipTab(this); return false;">
          <div class="tooltip-index">
            7</div>
        </div>
      </div>
    <div class="content-tabs">
      <div class="content-tab active" id="00009000_tooltipItem_content_tab">
          <div class="tooltip-tab-header">
            
    
      <div class="component-headline headline">
        
        Lifting eyes
      </div>
    
</div>
          
          <div class="content-tab-image-container">
                <img src="images/product/sContainer-tooltip-kranoesen.gif" class="tooltip-image">
              </div>
              <div class="content-tab-text-container image-exist">
            <div class="tooltip-tab-text">
              The eyelets can be optionally retrofitted in order to be able to move the sContainer on site with the crane.</div>
            </div>
        </div>
      <div class="content-tab" id="00009002_tooltipItem_content_tab">
          <div class="tooltip-tab-header">
            
      <div class="component-headline headline">
        
        Lock
      </div>
    
</div>
          
          <div class="content-tab-image-container">
                <img src="images/product/sContainer-tooltip-schloss.gif" class="tooltip-image">
              </div>
              <div class="content-tab-text-container image-exist">
            <div class="tooltip-tab-text">
              <p>You can choose from three locks for your sContainer. The most cost-effective option is a padlock, which provides solid anti-theft prevention. Alternatively, you can opt for a cylinder lock or even the high-end version, an electronic lock, which means that you have no need for keys.&nbsp;&nbsp;</p></div>
            </div>
        </div>
      <div class="content-tab" id="00009001_tooltipItem_content_tab">
          <div class="tooltip-tab-header">
            
    
      <div class="component-headline headline">
        
        Decal surface
      </div>
      
</div>
          
          <div class="content-tab-image-container">
                <img src="images/product/sContainer-tooltip-beklebung.jpg" class="tooltip-image">
              </div>
              <div class="content-tab-text-container image-exist">
            <div class="tooltip-tab-text">
              <p>The side panels of the sContainer provide an excellent advertising surface for your company. The StoreToGo graphics configurator lets you design and order the decals for your sContainer directly yourself – one-stop ordering and delivery.&nbsp;Simply select "StoreToGo" from the manufacturer and off you go!</p>
</div>
            </div>
        </div>
      <div class="content-tab" id="00009003_tooltipItem_content_tab">
          <div class="tooltip-tab-header">
            
    
      <div class="component-headline headline">
        
        Lifting lugs
      </div>
    
</div>
          
          <div class="content-tab-image-container">
                <img src="images/product/sContainer-tooltip-transport.jpg" class="tooltip-image">
              </div>
              <div class="content-tab-text-container image-exist">
            <div class="tooltip-tab-text">
              <p>The lugs can optionally be retrofitted to allow the sContainer to be moved by crane on site as well.</p></div>
            </div>
        </div>
      <div class="content-tab" id="00011000_tooltipItem_content_tab">
          <div class="tooltip-tab-header">
      <div class="component-headline headline">
        
        Height
      </div>
    
</div>
          
          <div class="content-tab-image-container">
                <img src="images/product/sContainer-tooltip-groessen.jpg" class="tooltip-image">
              </div>
              <div class="content-tab-text-container image-exist">
            <div class="tooltip-tab-text">
              <p>The sContainer is available in two different heights. The lower height (1,200 mm) is even suitable for transporting in lightweight vans. The taller version (1,900 mm) naturally offers you even more storage space in the interior of the container.</p>
</div>
            </div>
        </div>
      <div class="content-tab" id="00010001_tooltipItem_content_tab">
          <div class="tooltip-tab-header">
            
      <div class="component-headline headline">
        
        Interior
      </div>
    
</div>
          
          <div class="content-tab-image-container">
                <img src="images/product/sContainer-tooltip-innenraum.jpg" class="tooltip-image">
              </div>
              <div class="content-tab-text-container image-exist">
            <div class="tooltip-tab-text">
              The interior is conveniently accessed through a large door. A hard-wearing SoboGrip floor is used as the base. What is unique is the fact that SR5 van racking components are fitted in the interior to ensure optimum organisation and also load securing.</div>
            </div>
        </div>
      <div class="content-tab" id="00010000_tooltipItem_content_tab">
          <div class="tooltip-tab-header">    
    
      <div class="component-headline headline">
        
        Durable material
      </div>
</div>
          
          <div class="content-tab-image-container">
                <img src="images/product/sContainer-tooltip-material.jpg" class="tooltip-image">
              </div>
              <div class="content-tab-text-container image-exist">
            <div class="tooltip-tab-text">
              A massive frame forms the base, which permits a load capacity of up to 500 kg. The cladding is made of powder-coated sheet steel. A plastic cover reliably prevents the ingress of rainwater.</div>
            </div>
        </div>
      </div>
  </div>
</div></div>
</div>
<!-- END -->


<!-- STRT -->
<div class="row sty-wid">
<div class="yCmsComponent sortimo-component-slot clearfix">
<div id="00009004_textComponent" class="sortimo-component text-component big-header
">
  
      <div class="component-headline ">
        
        Different heights available
      </div>
    
</div></div>
</div>
<!-- END -->



<!-- STRT -->
<div class="row sty-wid1">
<div class="yCmsComponent sortimo-component-slot clearfix centet-all">
<div class="sortimo-component wide-low text-picture-component wide-low-left" id="cmsitem_00009004">
  <div class="row" style="background-color: #eeeff1;">
    <div class="image-container" style="width: 695px; height: 340px;
        background-image: url('images/product/sContainer-kacheln-2-groessen-690x340.jpg');  float: left;">
        <img src="images/product/sContainer-kacheln-2-groessen-690x340.jpg" style="visibility: hidden;">
      </div>  
    <div class="sortimo-blue-link text-container sortimo-dark-hover hudbnjk" style="width: 695px; min-height: 340px; float: right;background-color: #eeeff1;color: #546373;
      ">
      <div class="arrow-container" style="background-color: #eeeff1;"></div>
      

<div class="text">
        The sContainer is available in <strong>height 1.20 m and 1.90 m</strong>. The basic dimensions, which are based on the Euro pallet size, always remain the same. Depending on your requirements, you can order the sContainers with different variants of locking systems. Optionally, the sContainer can be equipped with crane eyelets, ventilation and individual advertising adhesives - depending on the application.</div>
    </div>
    </div>
</div></div>

</div>
<!-- END -->





<!-- STRT -->
<div class="row sty-wid">
<div class="yCmsComponent sortimo-component-slot clearfix">
<div id="00009006_textComponent" class="sortimo-component text-component big-header
">
    
      <div class="component-headline ">
        
        Work organization in no time
      </div>
      <div class="component-headline subheadline">
        
        Working more efficiently with SR5 and&nbsp;StoreToGo labels
      </div>
</div></div>
</div>
<!-- END -->




<!-- STRT -->
<div class="row sty-wid1">
<div class="yCmsComponent sortimo-component-slot clearfix centet-all">
<div class="sortimo-component wide-high text-picture-component wide-high-left" id="cmsitem_00009007">
  <div class="row" style="background-color: #eeeff1;">
    <div class="image-container" style="width: 695px; height: 510px;
        background-image: url('images/product/sContainer-sr5-695x510.jpg');  float: left;">
        <img src="images/product/sContainer-sr5-695x510.jpg" style="visibility: hidden;">
      </div>  
    <div class="sortimo-blue-link text-container sortimo-dark-hover hudbnjk" style="width: 695px; min-height: 510px; float: right;background-color: #eeeff1;color: #546373;
      ">
      <div class="arrow-container" style="background-color: #eeeff1;"></div>
      
      <div class="component-headline ">
        
        To the custom-fit shelving system SR5 for your sContainer
      </div>
    
    
  
<div class="text">
        The SR5 shelving system makes more effective work possible with optimal use of space! Request a consultation appointment to get the right SR5 shelf for your sContainer.<br>&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;
        </div>
    </div>
    </div>
</div></div>

</div>
<!-- END -->




<!-- STRT -->
<div class="row sty-wid">
<div class="yCmsComponent sortimo-component-slot clearfix centet-all">
<div class="sortimo-component wide-low text-picture-component wide-low-right" id="cmsitem_00009009">
  <div class="row" style="background-color: #eeeff1;">
    <div class="sortimo-blue-link text-container sortimo-dark-hover hudbnjk" style="width: 695px; min-height: 340px; float: left;background-color: #eeeff1;color: #546373;
      ">
      <div class="arrow-container" style="background-color: #eeeff1;"></div>
      
    
      <div class="component-headline ">
        
        With labels for more organisation in the sContainer
      </div>
    
    
  
<div class="text">
        Organize your workplace even more effectively with increased clarity thanks to the label labels StoreToGo labels.<br>&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;
        </div>
    </div>
    <div class="image-container" style="width: 695px; height: 340px;
        background-image: url('images/product/sContainer-beschriftungsetiketten-695x340.jpg');  float: right;">
        <img src="images/product/sContainer-beschriftungsetiketten-695x340.jpg" style="visibility: hidden;">
      </div>  
    </div>
</div></div>

</div>
<!-- END -->



<!-- STRT -->
<div class="row sty-wid">
<div class="yCmsComponent sortimo-component-slot clearfix">
<div id="00009009_textComponent" class="sortimo-component text-component big-header
">
     
    
      <div class="component-headline ">
        
        Design your sContainer individually 
      </div>
    
    
      <div class="component-headline subheadline">
        
        Quick and easy to perfect decal
      </div>
    
</div></div>
</div>
<!-- END -->

<!-- STRT -->
<div class="row sty-wid centet-all dshngsry">
<div class="yCmsComponent sortimo-component-slot">
<div class="sortimo-component square-small text-picture-component square-small-right dfsdf" id="cmsitem_00009011">
  <div class="row" style="background-color: #eeeff1;">
    <div class="sortimo-blue-link text-container sortimo-dark-hover" style="width: 340px; min-height: 340px; float: left;background-color: #eeeff1;color: #546373;
      ">
      <div class="arrow-container" style="background-color: #eeeff1;"></div>
      
      <div class="component-headline ">
        
        Personal advice
      </div>
    
    
  
<div class="text">
        Would you rather have personal advice on the selection of your decal? Arrange your appointment with one of our experts here.<br>&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;
<div></div>

        </div>
    </div>
    <div class="image-container" style="width: 340px; height: 340px;
        background-image: url('images/product/fahrzeugeinrichtung-sr5-beratung-340x340.jpg');  float: right;">
        <img src="images/product/fahrzeugeinrichtung-sr5-beratung-340x340.jpg" style="visibility: hidden;">
      </div>  
    </div>
</div></div>

<div class="yCmsComponent sortimo-component-slot">
<div class="sortimo-component square-small text-picture-component square-small-left dfsdf" id="cmsitem_00009012">
  <div class="row" style="background-color: #eeeff1;">
    <div class="image-container" style="width: 340px; height: 340px;
        background-image: url('images/product/sContainer-beklebungskonfigurator-340x340.jpg');  float: left;">
        <img src="images/product/sContainer-beklebungskonfigurator-340x340.jpg" style="visibility: hidden;">
      </div>  
    <div class="sortimo-blue-link text-container sortimo-dark-hover" style="width: 340px; min-height: 340px; float: right;background-color: #eeeff1;color: #546373;
      ">
      <div class="arrow-container" style="background-color: #eeeff1;"></div>
      
      <div class="component-headline ">
        
        Decal online configurable
      </div>
    
<div class="text">
        In simple steps, you can configure the desired sticker for your service depot online – user-friendly and fast. Simply select "StoreToGo" from the manufacturer and get started!<br>&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;</div>
    </div>
    </div>
</div></div>

</div>
<!-- END -->


<!-- STRT -->
<div class="row sty-wid">
  <div class="yCmsComponent sortimo-component-slot clearfix">
<div id="00009011_textComponent" class="sortimo-component text-component small-header
">
        <div class="component-headline ">
        
        Learn more.
      </div>
    
    
      <div class="component-headline subheadline">
        
        In the brochure you will find further product information and suitable accessories.
      </div>
  
</div></div>
</div>
<!-- END -->

<!-- STRT -->
<div class="row sty-wid1">
  <div class="yCmsComponent sortimo-component-slot clearfix">
<div class="sortimo-component download-component" id="cmsitem_00009013">
  <div class="download-item" onclick="window.open('images/product/EN-sContainer-Broschuere-A4-SCREEN.pdf', '_blank');">
      <div class="download-image">
        <img src="images/product/eng-sortimo-sContainer.jpg" class="image">
      </div>
      <div class="download-text">
        <div class="text-arrow"></div>
        <div class="text-container">
          <div class="name">sContainer</div>
          <div class="info">
            <div class="size">
                4,64&nbsp;MB</div>
            <div class="icon">
              <svg version="1.1" id="Ebene_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30px" height="49px" viewBox="0 0 20 32" style="enable-background: new 0 0 20 32;" xml:space="preserve">
                <style type="text/css">
                .st0 {
                  fill: #0068b4;
                }
                
                .st1 {
                  fill: #FFFFFF;
                }
                </style>
                <g>
                  <g>
                    <path class="st0" d="M12.5,7.1V0.2L1,0.1c-0.2,0-0.4,0.2-0.4,0.4v22.1C0.6,22.9,0.8,23,1,23h5.5l0-5l7.1,0l0,5h5.5
                      c0.2,0,0.4-0.2,0.4-0.4l0-15.6L12.5,7.1z"></path>
                    <polygon class="st0" points="19.5,6 13.7,6 13.7,0.2     "></polygon>
                  </g>
                  <g>
                    <path class="st1" d="M3.9,10.7h1.9c0.2,0,0.4,0,0.6,0.1c0.2,0.1,0.4,0.2,0.6,0.3c0.2,0.1,0.3,0.3,0.4,0.5c0.1,0.2,0.2,0.5,0.2,0.8
                      c0,0.4-0.1,0.8-0.4,1.1c-0.3,0.3-0.7,0.5-1.2,0.5H4.7V16H3.9V10.7z M4.7,13.2h1.2c0.3,0,0.5-0.1,0.7-0.3c0.1-0.2,0.2-0.4,0.2-0.6
                      c0-0.2,0-0.3-0.1-0.5c-0.1-0.1-0.1-0.2-0.2-0.3c-0.2-0.1-0.3-0.2-0.6-0.2H4.7V13.2z"></path>
                    <path class="st1" d="M8.3,10.7h1.8c0.7,0,1.2,0.3,1.6,0.9c0.1,0.2,0.2,0.4,0.2,0.6c0,0.2,0,0.6,0,1.1c0,0.6,0,1-0.1,1.2
                      c0,0.1,0,0.2-0.1,0.3c0,0.1-0.1,0.2-0.1,0.3c-0.2,0.3-0.4,0.5-0.6,0.6c-0.3,0.2-0.6,0.3-1,0.3H8.3V10.7z M9.1,15.3h0.9
                      c0.4,0,0.8-0.2,1-0.5c0.1-0.1,0.1-0.3,0.2-0.4c0-0.2,0-0.5,0-1c0-0.5,0-0.8,0-1c0-0.2-0.1-0.4-0.2-0.5c-0.2-0.3-0.5-0.5-0.9-0.5
                      H9.1V15.3z"></path>
                    <path class="st1" d="M13.1,10.7h3.3v0.8h-2.5V13H16v0.7h-2.2V16h-0.8V10.7z"></path>
                  </g>
                  <polygon class="st0" points="12.5,24.1 12.5,19.1 7.6,19.1 7.6,24.1 3.6,24.1 10,31.4 16.6,24.1   "></polygon>
                </g>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div></div>
</div>
<!-- END -->



    </div>
  </section>




<!-- STRT -->
<div class="row sty-wid1">
  
</div>
<!-- END -->

    </div>
  </section>
    
   
    <?php include'footer.php';?>
    

   
    <script type="text/javascript" src="js/storetogoModules.js"></script>
    
    
    

<script type="text/javascript">
  // vars
'use strict'
var testim = document.getElementById("testim"),
    testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
    testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
    testimLeftArrow = document.getElementById("left-arrow"),
    testimRightArrow = document.getElementById("right-arrow"),
    testimSpeed = 4500,
    currentSlide = 0,
    currentActive = 0,
    testimTimer,
    touchStartPos,
    touchEndPos,
    touchPosDiff,
    ignoreTouch = 30;
;

window.onload = function() {

    // Testim Script
    function playSlide(slide) {
        for (var k = 0; k < testimDots.length; k++) {
            testimContent[k].classList.remove("active");
            testimContent[k].classList.remove("inactive");
            testimDots[k].classList.remove("active");
        }

        if (slide < 0) {
            slide = currentSlide = testimContent.length-1;
        }

        if (slide > testimContent.length - 1) {
            slide = currentSlide = 0;
        }

        if (currentActive != currentSlide) {
            testimContent[currentActive].classList.add("inactive");            
        }
        testimContent[slide].classList.add("active");
        testimDots[slide].classList.add("active");

        currentActive = currentSlide;
    
        clearTimeout(testimTimer);
        testimTimer = setTimeout(function() {
            playSlide(currentSlide += 1);
        }, testimSpeed)
    }

    testimLeftArrow.addEventListener("click", function() {
        playSlide(currentSlide -= 1);
    })

    testimRightArrow.addEventListener("click", function() {
        playSlide(currentSlide += 1);
    })    

    for (var l = 0; l < testimDots.length; l++) {
        testimDots[l].addEventListener("click", function() {
            playSlide(currentSlide = testimDots.indexOf(this));
        })
    }

    playSlide(currentSlide);

    // keyboard shortcuts
    document.addEventListener("keyup", function(e) {
        switch (e.keyCode) {
            case 37:
                testimLeftArrow.click();
                break;
                
            case 39:
                testimRightArrow.click();
                break;

            case 39:
                testimRightArrow.click();
                break;

            default:
                break;
        }
    })
    
    testim.addEventListener("touchstart", function(e) {
        touchStartPos = e.changedTouches[0].clientX;
    })
  
    testim.addEventListener("touchend", function(e) {
        touchEndPos = e.changedTouches[0].clientX;
      
        touchPosDiff = touchStartPos - touchEndPos;
      
        console.log(touchPosDiff);
        console.log(touchStartPos); 
        console.log(touchEndPos); 

      
        if (touchPosDiff > 0 + ignoreTouch) {
            testimLeftArrow.click();
        } else if (touchPosDiff < 0 - ignoreTouch) {
            testimRightArrow.click();
        } else {
          return;
        }
      
    })
}
</script>



    
   
</body>
</html>
